﻿
using Microsoft.AspNetCore.Mvc;
using ToDoList.Models;


namespace ToDoList.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
        
    }
    [Route("/")]
    public IActionResult Index()

    {
        Item starterItem = new Item("Add first item to To Do List");
        return View(starterItem);
        
    }

    [Route("/items/new")]
    public ActionResult CreateForm()
    {
        return View();
    }

    [Route("/items")]
    public ActionResult Create(string description)
    {
        Item myItem = new Item(description);
        return View("Index", myItem);
    }

}


